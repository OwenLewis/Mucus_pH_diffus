%This script begins a simulation. Generally this is passed as an argument
%to a background matlab process via the command line. 
clear all

%These three variables (first 2 are structs) must be declared global for
%the simulation
global GelState GelSimParams rescaled

%Load the three above variables from InitialData.mat (must be in pwd)
load('InitialData.mat')

%Add the directory where all source files reside to the path
path('~/Matlab/ImplicitBuffering',path)

%Call the main time integration loop
MainTimeLoop
